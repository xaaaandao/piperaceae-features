# script to regions....
for i in $(seq 1 33); do
    for size in 256 400 512; do
        for color in RGB; do
            echo $i $size;
            mkdir -p /home/xandao/Documentos/regions_dataset+South+20/${color}/${size}/vit_large
            python FeatureExtraction.py --modelo ViT_large --origem /home/xandao/Documentos/regions_dataset+South+20/RGB/${size}/mobilenetv2/images/f${i} --armazenar /home/xandao/Documentos/regions_dataset+South+20/${color}/${size}/vit_large --nome f${i} --cor ${color}
        done
    done
done

for i in $(seq 1 49); do
    for size in 256 400 512; do
        for color in RGB; do
            echo $i $size;
            mkdir -p /home/xandao/Documentos/regions_dataset+South+10/${color}/${size}/vit_large
            python FeatureExtraction.py --modelo ViT_large --origem /home/xandao/Documentos/regions_dataset+South+10/RGB/${size}/mobilenetv2/images/f${i} --armazenar /home/xandao/Documentos/regions_dataset+South+10/${color}/${size}/vit_large --nome f${i} --cor ${color}
        done
    done
done


for i in $(seq 1 72); do
    for size in 256 400 512; do
        for color in RGB; do
            echo $i $size;
            mkdir -p /home/xandao/Documentos/regions_dataset+South+5/${color}/${size}/vit_large
            python FeatureExtraction.py --modelo ViT_large --origem /home/xandao/Documentos/regions_dataset+South+5/RGB/${size}/mobilenetv2/images/f${i} --armazenar /home/xandao/Documentos/regions_dataset+South+5/${color}/${size}/vit_large --nome f${i} --cor ${color}
        done
    done
done
