# script to regions....
for i in $(seq 1 41); do
    for size in 256 400 512; do
        for color in RGB; do
            echo $i $size;
            mkdir -p /home/xandao/Documentos/regions_dataset+North+20/${color}/${size}/vit_large
            python FeatureExtraction.py --modelo ViT_large --origem /home/xandao/Documentos/regions_dataset+North+20/RGB/${size}/mobilenetv2/images/f${i} --armazenar /home/xandao/Documentos/regions_dataset+North+20/${color}/${size}/vit_large --nome f${i} --cor ${color}
        done
    done
done

for i in $(seq 1 68); do
    for size in 256 400 512; do
        for color in RGB; do
            echo $i $size;
            mkdir -p /home/xandao/Documentos/regions_dataset+North+10/${color}/${size}/vit_large
            python FeatureExtraction.py --modelo ViT_large --origem /home/xandao/Documentos/regions_dataset+North+10/RGB/${size}/mobilenetv2/images/f${i} --armazenar /home/xandao/Documentos/regions_dataset+North+10/${color}/${size}/vit_large --nome f${i} --cor ${color}
        done
    done
done


for i in $(seq 1 107); do
    for size in 256 400 512; do
        for color in RGB; do
            echo $i $size;
            mkdir -p /home/xandao/Documentos/regions_dataset+North+5/${color}/${size}/vit_large
            python FeatureExtraction.py --modelo ViT_large --origem /home/xandao/Documentos/regions_dataset+North+5/RGB/${size}/mobilenetv2/images/f${i} --armazenar /home/xandao/Documentos/regions_dataset+North+5/${color}/${size}/vit_large --nome f${i} --cor ${color}
        done
    done
done
