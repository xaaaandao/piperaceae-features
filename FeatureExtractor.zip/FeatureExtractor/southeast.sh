# script to regions....
for i in $(seq 1 42); do
    for size in 256 400 512; do
        for color in RGB; do
            echo $i $size;
            mkdir -p /home/xandao/Documentos/regions_dataset+Southeast+20/${color}/${size}/vit_large
            python FeatureExtraction.py --modelo ViT_large --origem /home/xandao/Documentos/regions_dataset+Southeast+20/RGB/${size}/mobilenetv2/images/f${i} --armazenar /home/xandao/Documentos/regions_dataset+Southeast+20/${color}/${size}/vit_large --nome f${i} --cor ${color}
        done
    done
done

for i in $(seq 1 67); do
    for size in 256 400 512; do
        for color in RGB; do
            echo $i $size;
            mkdir -p /home/xandao/Documentos/regions_dataset+Southeast+10/${color}/${size}/vit_large
            python FeatureExtraction.py --modelo ViT_large --origem /home/xandao/Documentos/regions_dataset+Southeast+10/RGB/${size}/mobilenetv2/images/f${i} --armazenar /home/xandao/Documentos/regions_dataset+Southeast+10/${color}/${size}/vit_large --nome f${i} --cor ${color}
        done
    done
done


for i in $(seq 1 102); do
    for size in 256 400 512; do
        for color in RGB; do
            echo $i $size;
            mkdir -p /home/xandao/Documentos/regions_dataset+Southeast+5/${color}/${size}/vit_large
            python FeatureExtraction.py --modelo ViT_large --origem /home/xandao/Documentos/regions_dataset+Southeast+5/RGB/${size}/mobilenetv2/images/f${i} --armazenar /home/xandao/Documentos/regions_dataset+Southeast+5/${color}/${size}/vit_large --nome f${i} --cor ${color}
        done
    done
done
