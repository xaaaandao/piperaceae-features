# script to pr....
for i in $(seq 1 23); do
    for size in 256 400 512; do
        for color in RGB; do
            echo $i $size;
            mkdir -p /home/xandao/Documentos/pr_dataset+20/${color}/${size}/vit_large
            python FeatureExtraction.py --modelo ViT_large --origem /home/xandao/Documentos/pr_dataset+20/${color}/${size}/images/f${i} --armazenar /home/xandao/Documentos/pr_dataset+20/${color}/${size}/vit_large --nome f${i} --cor ${color}
        done
    done
done

for i in $(seq 1 36); do
    for size in 256 400 512; do
        for color in RGB; do
            echo $i $size;
            mkdir -p /home/xandao/Documentos/pr_dataset+10/${color}/${size}/vit_large
            python FeatureExtraction.py --modelo ViT_large --origem /home/xandao/Documentos/pr_dataset+10/${color}/${size}/images/f${i} --armazenar /home/xandao/Documentos/pr_dataset+10/${color}/${size}/vit_large --nome f${i} --cor ${color}
        done
    done
done


for i in $(seq 1 55); do
    for size in 256 400 512; do
        for color in RGB; do
            echo $i $size;
            mkdir -p /home/xandao/Documentos/pr_dataset+5/${color}/${size}/vit_large
            python FeatureExtraction.py --modelo ViT_large --origem /home/xandao/Documentos/pr_dataset+5/${color}/${size}/images/f${i} --armazenar /home/xandao/Documentos/pr_dataset+5/${color}/${size}/vit_large --nome f${i} --cor ${color}
        done
    done
done
