# script to pr....
for i in $(seq 1 106); do
    for size in 256 400 512; do
        for color in RGB; do
            echo $i $size;
            mkdir -p /home/xandao/Documentos/br_dataset+20/${color}/${size}/vit_large
            python FeatureExtraction.py --modelo ViT_large --origem /home/xandao/Documentos/br_dataset+20/RGB/${size}/images/f${i} --armazenar /home/xandao/Documentos/br_dataset+20/${color}/${size}/vit_large --nome f${i} --cor ${color}
    done
        done
done

for i in $(seq 1 160); do
    for size in 256 400 512; do
        for color in RGB; do
            echo $i $size;
            mkdir -p /home/xandao/Documentos/br_dataset+10/${color}/${size}/vit_large
            python FeatureExtraction.py --modelo ViT_large --origem /home/xandao/Documentos/br_dataset+10/RGB/${size}/images/f${i} --armazenar /home/xandao/Documentos/br_dataset+10/${color}/${size}/vit_large --nome f${i} --cor ${color}
        done
    done
done


for i in $(seq 1 236); do
    for size in 256 400 512; do
        for color in RGB; do
            echo $i $size;
            mkdir -p /home/xandao/Documentos/br_dataset+5/${color}/${size}/vit_large
            python FeatureExtraction.py --modelo ViT_large --origem /home/xandao/Documentos/br_dataset+5/RGB/${size}/images/f${i} --armazenar /home/xandao/Documentos/br_dataset+5/${color}/${size}/vit_large --nome f${i} --cor ${color}
        done
    done
done
